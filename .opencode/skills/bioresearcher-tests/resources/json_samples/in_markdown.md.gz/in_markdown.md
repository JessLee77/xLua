# Document with Embedded JSON

Some text here.

```json
{"embedded": true, "count": 5, "source": "markdown"}
```

More text after.
